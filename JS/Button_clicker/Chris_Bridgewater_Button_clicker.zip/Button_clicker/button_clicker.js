// log-in button

function turnOff(element) {
    element.innerText = "Logout";
}

// definition button

function hide(element) {
    element.remove();
}