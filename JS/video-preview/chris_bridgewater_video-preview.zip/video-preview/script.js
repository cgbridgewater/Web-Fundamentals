console.log("page loaded...");


function subscribed(element) {
    element.innerText = "Subscribed";
}
