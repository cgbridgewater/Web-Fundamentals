// like tab 1
function updateCounter1(){
    console.log(typeof counter1.innerText);
    newNum1 = parseInt(counter1.innerText)
    console.log(typeof newNum1);
    counter1.innerText = newNum1 +=1;
}

// like tab 2
function updateCounter2(){
    console.log(typeof counter2.innerText);
    newNum2 = parseInt(counter2.innerText)
    console.log(typeof newNum2);
    counter2.innerText = newNum2 +=1;
}

// like tab 3
function updateCounter3(){
    console.log(typeof counter3.innerText);
    newNum3 = parseInt(counter3.innerText)
    console.log(typeof newNum3);
    counter3.innerText = newNum3 +=1;
}
